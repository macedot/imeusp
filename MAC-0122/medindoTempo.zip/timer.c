#include <stdio.h>
#include <stdlib.h>

#define VSIZE 1000
#define LINUX

/* Se estiver rodando no linux, melhor usarmos as funcoes que medem ate' 
   microsegundos e sao razoavelmente precisas. A outra estrategia usa o 
   timer.h, um conjunto de macros feitas por Scott Kaplan, que por sua vez 
   modificou as funcoes zenTimer escritas por Mark Johnston. A ideia aqui
   e' usar o registrador TSC que conta quantos ciclos passaram-se desde que
   a maquina foi ligada. Embora funcione tanto no linux como no windows, 
   ela so� e' bem precisa se a quantidade de ciclos a serem medidos for 
   menor que o slice de tempo dado para o processo a cada mudanca de 
   contexto. Caso contrario, melhor rodar o programa a ser medido com o 
   sistema minimamente usado, isto e', pare a execucao de todos os outros
   processos que nao afetam o funcionamento do sistema. Outro problema com
   essa estrategia e' a portabilidade. Para transformar ciclos em segundos,
   precisamos saber o clock da CPU.*/

/* Para executar este programa, nao use a opcao -ansi do compilador */

#ifdef LINUX
#include <sys/time.h>
#include <sys/resource.h>
#else
#include "timer.h"
#endif

/* Funcao para subtrair structs timeval. Esta funcao esta' relatada
   no manual da glibc                                               */

/* Subtract the `struct timeval' values X and Y,
   storing the result in RESULT.
   Return 1 if the difference is negative, otherwise 0.  */
     
int timeval_subtract(struct timeval *result, struct timeval *x, struct timeval *y) {
  /* Perform the carry for the later subtraction by updating y. */
  if (x->tv_usec < y->tv_usec) {
    int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
    y->tv_usec -= 1000000 * nsec;
    y->tv_sec += nsec;
  }
  if (x->tv_usec - y->tv_usec > 1000000) {
    int nsec = (x->tv_usec - y->tv_usec) / 1000000;
    y->tv_usec += 1000000 * nsec;
    y->tv_sec -= nsec;
  }
  
  /* Compute the time remaining to wait.
     tv_usec is certainly positive. */
  result->tv_sec = x->tv_sec - y->tv_sec;
  result->tv_usec = x->tv_usec - y->tv_usec;
  
  /* Return 1 if result is negative. */
  return x->tv_sec < y->tv_sec;
}

/* Um exemplo bobo que mede o tempo gasto para a ordenacao
   de um vetor desordenado de tamanho VSIZE, usando selecao
   otimizada                                                */

int main(){
 
#ifdef LINUX
  struct timeval tu0, ts0, tuf, tsf , time_sys, time_usr ;
  struct rusage rusage;
#else
  zenTimerType timer ;
#endif


  int V[VSIZE] ; 
  int i, j, menor, imenor ;
  int long long count ;

  srand(123455) ;
 
  /* Preeche o vetor com numeros inteiros de 0 a 9 */
  for(i = 0 ; i < VSIZE; i++){
    V[i] = rand()%10 ;
  }

  /* Toma o valor inicial do tempo */ 
#ifdef LINUX
  getrusage(RUSAGE_SELF,&rusage);
  tu0 = rusage.ru_utime ;
  ts0 = rusage.ru_stime ;
#else
  START_ZEN_TIME(timer);
#endif

  /* Executa o algoritmo, propriamente dito */
  for(i = 0 ; i < VSIZE-1; i++){
    menor = V[i] ;
    imenor = i ;
    for(j=i+1; j < VSIZE; j++) {
      if(menor > V[j]) {
        menor = V[j] ;
        imenor = j ;
      }
    }
    V[imenor] =  V[i] ;
    V[i] = menor ;
  }

  /* Toma o tempo final, subtrai do inicial e imprime */
#ifdef LINUX
  getrusage(RUSAGE_SELF,&rusage);
  tuf = rusage.ru_utime ;
  tsf = rusage.ru_stime ;
  timeval_subtract(&time_sys,&tsf,&ts0) ;
  timeval_subtract(&time_usr,&tuf,&tu0) ;

  printf("user: %ld seconds and %ld microseconds\n",time_usr.tv_sec, time_usr.tv_usec) ;
  printf("system: %ld seconds and %ld microseconds\n",time_sys.tv_sec, time_sys.tv_usec) ;
#else
  STOP_ZEN_TIME(timer,count);
  printf("Count: %lld\n",count) ;
#endif

  return(0) ;
}
