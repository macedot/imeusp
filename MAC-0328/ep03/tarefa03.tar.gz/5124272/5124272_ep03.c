/*
tmacedo
32016362
Thiago Pinheiro de Macedo
5124272
*/
/* "Mantido para manter" o padrao =) */
/******************************************************************************
* Inclusoes da LIB padrao 
******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <malloc.h>
#include <ctype.h>

/******************************************************************************
* Definicoes internas do modulo 
******************************************************************************/
#define SEPARA_DEP              ' '
#define SEPARA_CMD              ';'
#define MAX_VERTEX				(50000)
#define MAX_LINE				(4096)
#define JUMP_SPACES(p)			{while(isspace(*p)) p++;}
#define STRNCPY(dest,orig,size)	{strncpy(dest, orig, size);  dest[size] = 0;}

#ifndef FALSE
#	define FALSE				(0)
#endif

#ifndef TRUE
#	define TRUE					(1)
#endif

/******************************************************************************
* Definicoes de relacao entre funcoes para digrafos e grafos;
******************************************************************************/
#define Vertex	int

/******************************************************************************
* Definicoes de estruturas de base do modulo
******************************************************************************/
typedef struct link {
	Vertex w;
	struct link* next;
} *Link;

typedef struct digraph {
	int		V;
	int		A;
	Link*	adj;
} *Digraph;

/******************************************************************************
* Variaveis globais internas do modulo
******************************************************************************/
static int  idxVertex = -1;
static int  idxTarget = -1;
static char *szListName[MAX_VERTEX];
static char *szListCmd[MAX_VERTEX];
static char szAuxLine[MAX_LINE+1];

static const char szMakeFileIn[]  = "MakeFile";
static const char szMakeFileOut[] = "MakeFile.dg";

/******************************************************************************
* Link NewLink(Vertex w, Link next) 
* Criacao de novo elemento da lista de vetices;
******************************************************************************/
Link NewLink(Vertex w, Link next) 
{
	Link x;

	x = (Link)malloc(sizeof *x);
	x->w = w;
	x->next = next;
	return x;
}
/******************************************************************************
* Digraph DIGRAPHinit(Vertex V) 
* Inicializacao de novo drigrafo com V vertices;
******************************************************************************/
Digraph DIGRAPHinit(Vertex V) 
{
	Digraph  G;
	Vertex   v;

	G = (Digraph)malloc(sizeof *G);
	G->V = V;
	G->A = 0;
	G->adj = (Link*)malloc(V * sizeof(Link*));
	for(v = 0; v < G->V; v++)
	{
		G->adj[v] = NULL;
	}
	return G;
}
/******************************************************************************
* void DIGRAPHfree(Digraph G) 
* Liberacao de drigrafo alocado em DIGRAPHinit e seus respectivos elementos;
******************************************************************************/
void DIGRAPHfree(Digraph G) 
{
	Vertex  v;
	Link    p, l;

	for(v = 0; v < G->V; v++)
	{
		p = G->adj[v];
		while(p != NULL)
		{
			l = p;
			p = p->next;
			free(l);
		}
	}
	free(G);
}
/******************************************************************************
* void DIGRAPHinsertA(Digraph G, Vertex v, Vertex w)
* Inclusao de novo elemento ARESTA v-w num digrafo G existente e valido;
******************************************************************************/
int DIGRAPHinsertA(Digraph G, Vertex v, Vertex w)
{
	Link  p;

	/* verifica consistencia dos parametros recebidos
	(extremos e arcos em si mesmo) */
	if(v == w || v >= G->V || w >= G->V) 
	{
		return FALSE;
	}
	/* verifica se o arco ja nao existe no digrafo */
	for(p = G->adj[v]; p != NULL; p = p->next)
	{
		if(p->w == w) 
		{
			return FALSE;
		}
	}
	/* arco valido: aloca e atribui */
	G->adj[v] = NewLink(w, G->adj[v]);
	G->A++;
	return TRUE;
}
/******************************************************************************
* char* preParseMakeLine(char* szLine);
* Pre tratamento de uma linha lida do arquivo MakeFile;
******************************************************************************/
char* preParseMakeLine(char* szLine)
{
	char* pLine  = szLine;
	char* pToken = szLine;

	JUMP_SPACES(pLine);

	/* Remove quebras de linha; */
	if((pToken = strrchr(pLine, '\r')) != NULL)  *pToken = 0;
	if((pToken = strrchr(pLine, '\n')) != NULL)  *pToken = 0;

	/* Retorna novo inicio; */
	return pLine;
}
/******************************************************************************
* int findName(char* szList[], char* szName)
******************************************************************************/
int findName(char* szList[], char* szName)
{
	int i;

	for(i = 0; (szList[i] != NULL) && (i < MAX_VERTEX); i++)
	{
		if(strcmp(szList[i], szName) == 0)
			return i;
	}
	return -1;
}
/******************************************************************************
* int parseMakeDepend(char* szLine, Digraph G);
* Procede tratamento de uma linha de dependencia do arquivo MakeFile;
******************************************************************************/
int parseMakeDepend(char* szLine, Digraph G)
{
	char*  pToken;
	char*  pSepara;
	int    nSize;
	int    idxDepend;

	if((pToken = strchr(szLine, ':')) == NULL)
		return FALSE;

	idxTarget = ++idxVertex;
	nSize = (pToken - szLine);
	szListName[idxTarget] = (char*)malloc((1 + nSize) * sizeof(char));
	STRNCPY(szListName[idxTarget], szLine, nSize);

	pToken++; /* Pula o token (:) */
	JUMP_SPACES(pToken);

	/* Percorre linha buscando pelo separador de dependencias; */
	while((pSepara = strchr(pToken, SEPARA_DEP)) != NULL)
	{
		/* Obtem o tamanho da entrada de dependencia; */
		nSize = (pSepara - pToken);
		STRNCPY(szAuxLine, pToken, nSize);
		/* Verifica se ela ja eh uma dependencia conhecida; */
		if((idxDepend = findName(szListName, szAuxLine)) == -1)
		{
			/* Aloca novo local para armazenar a dependecia; */
			idxDepend = ++idxVertex;
			szListName[idxDepend] = (char*)malloc((1 + nSize) * sizeof(char));
			STRNCPY(szListName[idxDepend], szAuxLine, nSize);
		}
		/* Cria associacao de dependencia; */
		DIGRAPHinsertA(G, idxTarget, idxDepend);
		pToken = (pSepara + 1); /* Pula o caracter de separacao de dependencia; */
		JUMP_SPACES(pToken);
	}
	/* Verifica se sobrou alguem na linha; */
	if(pToken != NULL && *pToken != 0)
	{
		/* trata ultimo elemento, buscando pelo token de fim de string; */
		if((pSepara = strchr(pToken, '\0')) != NULL)
		{
			/* Conteudo restante */
			nSize = (pSepara - pToken);
			STRNCPY(szAuxLine, pToken, nSize);
			/* Verifica se ela ja eh uma dependencia conhecida; */
			if((idxDepend = findName(szListName, szAuxLine)) == -1)
			{
				/* Aloca novo local para armazenar a dependecia; */
				idxDepend = ++idxVertex;
				szListName[idxDepend] = (char*)malloc((1 + nSize) * sizeof(char));
				STRNCPY(szListName[idxDepend], szAuxLine, nSize);
			}
			/* Cria associacao de dependencia; */
			DIGRAPHinsertA(G, idxTarget, idxDepend);
		}
	}

	return TRUE;
}
/******************************************************************************
* int parseMakeCmd(char* szLine);
* Procede tratamento de uma linha de comando do arquivo MakeFile;
******************************************************************************/
int parseMakeCmd(char* szLine)
{
	int   nSize    = 0;
	int   nSizeAtu = 0;
	char* pAllCmd  = NULL;

	/* Nenhum target atribuido ao comando -> erro de especificacao; */
	if(idxTarget < 0)
		return FALSE;

	nSize = strlen(szLine);
	/* Verifica a pre existencia de comandos para este target; */
	if(szListCmd[idxTarget] != NULL)
	{
		nSizeAtu = strlen(szListCmd[idxTarget]);
	}

	/* Alocacao independe da pre existencia; */
	pAllCmd = (char*)realloc(szListCmd[idxTarget], (nSizeAtu + nSize + 2)*sizeof(char));
	if(pAllCmd == NULL)
		return FALSE;
	szListCmd[idxTarget] = pAllCmd;

	/* Se pre existe um comando, concatena o atual ao final da linnha, 
	separado pelo respectivo separador de comando; */
	if(nSizeAtu > 0)
	{
		pAllCmd[nSizeAtu++] = SEPARA_CMD;
	}
	memcpy(pAllCmd+nSizeAtu, szLine, nSize);
	*(pAllCmd+nSizeAtu+nSize) = 0;

	return TRUE;
}
/******************************************************************************
* int DIGRAPHprintMake(FILE* fp, Digraph G);
******************************************************************************/
int DIGRAPHprintMake(FILE* fp, Digraph G)
{
	char*  pToken;
	char*  pSepara;
	int    nSize;
	Vertex  v;
	Link    p;
	
	for(v = 0; v < G->V; v++)
	{
		/* Se nao existe a entrada na lista, nao ha o que fazer para ela; */
		if(szListName[v] == NULL)
			continue;

		/* Se nao existe um comando para a linha, 
		o nome nao se refere a um target; */
		if(szListCmd[v] == NULL)
			continue;

		/* Grava linha do target e suas dependencias */
		fprintf(fp,"%s :", szListName[v]);
		for(p = G->adj[v]; p != NULL; p = p->next)
		{
			fprintf(fp," %s", szListName[p->w]);
		}
		fprintf(fp,"\n");

		/* Grava linhas de comandos do target; */
		pToken = szListCmd[v];
		while((pSepara = strchr(pToken, SEPARA_CMD)) != NULL)
		{
			nSize = (pSepara - pToken);
			STRNCPY(szAuxLine, pToken, nSize);
			fprintf(fp,"\t%s\n", szAuxLine);
			pToken = (pSepara + 1); /* Pula o caracter de separacao de dependencia; */
		}
		/* Verifica se sobrou alguem na linha; */
		if(pToken != NULL && *pToken != 0)
		{
			/* trata ultimo elemento, buscando pelo token de fim de string; */
			if((pSepara = strchr(pToken, '\0')) != NULL)
			{
				nSize = (pSepara - pToken);
				STRNCPY(szAuxLine, pToken, nSize);
				fprintf(fp,"\t%s\n", szAuxLine);
			}
		}
		fprintf(fp,"\n");
	}
	return TRUE;
}
/******************************************************************************
* int main(void)
* Funcao principal e ponto de entrada do modulo;
******************************************************************************/
int main(void)
{
	Digraph  G;
	FILE* fpMake = NULL;
	char  szLine[MAX_LINE+1];
	char* pLine  = NULL;
	char* pToken = NULL;
	int   nLine = 0;
	int   i     = 0;
	int   nRet  = 0;

	
	if((fpMake = fopen(szMakeFileIn, "r+b")) == NULL) 
	{
		fprintf(stderr, "Erro abrindo o arquivo de entrada: '%s'\n", 
				szMakeFileIn);
		return 1;
	}

	for(i = 0; i < MAX_VERTEX; i++)
	{
		szListName[i] = szListCmd[i] = NULL;
	}
	G = DIGRAPHinit(MAX_VERTEX);

	while(fgets(szLine, MAX_LINE, fpMake) != NULL)
	{
		nLine++;
		/* Processa linha somente se for valida; */
		pLine = preParseMakeLine(szLine);
		if(pLine == NULL || *pLine == 0) continue;
		/* Verifica em que etapa estamos no arquivo */
		if((pToken = strchr(pLine, ':')) != NULL)
		{
			if(!parseMakeDepend(pLine, G))
			{
				fprintf(stderr, ">>> Erro de especificao do target ('%s' @ L%d) <<<\n", 
						szMakeFileIn, nLine);
				nRet = 1;
				break; /* while(fgets) */
			}
		}
		else
		{
			if(!parseMakeCmd(pLine))
			{
				fprintf(stderr, ">>> Erro de especificao de comando ('%s' @ L%d) <<<\n", 
						szMakeFileIn, nLine);
				nRet = 1;
				break; /* while(fgets) */
			}
		}
	}
	fclose(fpMake);

	/* Construcao do arquivo MakeFile.dg; */
	if((fpMake = fopen(szMakeFileOut, "w+b")) == NULL) 
	{
		fprintf(stderr, "Erro criando o arquivo de saida: '%s'\n", 
				szMakeFileOut);
		return 1;
	}
	/* Percorre digrafo e imprime com a estrutura desejada; */
	DIGRAPHprintMake(fpMake, G);
	fclose(fpMake);

	/* Liberacao de recursos alocados */
	DIGRAPHfree(G);
	for(i = 0; i < MAX_VERTEX; i++)
	{
		if(szListName[i] != NULL)
			free(szListName[i]);

		if(szListCmd[i] != NULL)
			free(szListCmd[i]);

		szListName[i] = szListCmd[i] = NULL;
	}
	return nRet;
}
